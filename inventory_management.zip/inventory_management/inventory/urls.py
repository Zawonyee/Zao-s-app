from django.urls import path
from . import views, admin



urlpatterns = [
    path('products/', views.product_list, name='product_list'),
    path('products/create/', views.product_create, name='product_create'),
    path('products/update/<int:pk>/', views.product_update, name='product_update'),
    path('products/delete/<int:pk>/', views.product_delete, name='product_delete'),
    path('import_products/', views.import_products, name='import_products'),
    path('clear-products/', views.clear_products, name='clear_products'),
    path('changes/', views.inventory_change_list, name='inventory_change_list'),
    path('import/', views.import_excel, name='import_excel'),
    path('products/detect-anomalies/', views.detect_anomalies_all_view, name='detect_anomalies_all'),
    path('products/manage-suggestions/', views.manage_suggestions_view, name='manage_suggestions'),
]
