# inventory/forms.py
from django import forms
from .models import Product

class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ['name', 'quantity', 'price','category', 'production_date', 'shelf_life']
        labels = {
            'name': '商品名称',
            'quantity': '库存数量',
            'price': '价格',
            'category': '类别',
            'production_date': '生产日期',
            'shelf_life': '保质期',
        }
        widgets = {
            'production_date': forms.DateInput(attrs={'type': 'date'}),
        }

class ImportForm(forms.Form):
    file = forms.FileField(label="上传 Excel 文件")