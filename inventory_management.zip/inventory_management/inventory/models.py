from django.db import models
from django.utils import timezone
import datetime
from django.contrib.auth.models import User  # 记录用户
class Product(models.Model):
    name = models.CharField(default='空商品',max_length=255)
    description = models.TextField(default='')
    price = models.DecimalField(default=0,max_digits=10, decimal_places=2)
    category = models.CharField(default='其它',max_length=100)#种类
    quantity = models.PositiveIntegerField(default=0)#库存量
    production_date = models.DateField(default=timezone.now)  # 生产日期字段
    shelf_life = models.IntegerField(default=30)#保质期
 # 保质期字段，单位：天

    def __str__(self):
        return self.name
class InventoryChange(models.Model):
    user = models.CharField(default='admin1',max_length=255)#用户名
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    change_amount = models.IntegerField()  # 正数表示增加，负数表示减少
    change_time = models.DateTimeField(default=datetime.datetime.now)  # 自动记录时间
    reason = models.CharField(max_length=255)  # 操作原因（例如：添加、出售等）

    def __str__(self):
        return f"{self.product.name} - {self.change_amount} on {self.change_time}"


class StockModificationRecord(models.Model):
    product = models.ForeignKey('Product', on_delete=models.CASCADE)  # 关联的货品
    user = models.ForeignKey(User, on_delete=models.CASCADE)  # 修改的用户
    old_quantity = models.PositiveIntegerField()  # 修改前的库存量
    new_quantity = models.PositiveIntegerField()  # 修改后的库存量
    timestamp = models.DateTimeField(default=timezone.now)  # 修改时间

    def __str__(self):
        return f"Product: {self.product.name}, Old: {self.old_quantity}, New: {self.new_quantity}, User: {self.user.username}, Time: {self.timestamp}"

