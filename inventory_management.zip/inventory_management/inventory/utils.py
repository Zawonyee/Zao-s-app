# inventory/utils.py
from .models import InventoryChange,Product
from django.db import models
import numpy as np
from sklearn.linear_model import LinearRegression
# 定义出售分析算法
def sales_analysis(product):
    # 在这里进行所有销售分析逻辑
    total_sales = InventoryChange.objects.filter(product=product, reason='出售').aggregate(total_sales=models.Sum('change_amount'))
    return abs(total_sales['total_sales']) if total_sales['total_sales'] else 0


from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures
from sklearn.pipeline import make_pipeline
from sklearn.ensemble import RandomForestRegressor
def restock_prediction(product_id, num_simulations=1000, days_ahead=30):
    # 获取产品和历史销售数据
    product = Product.objects.get(id=product_id)
    sales_data = InventoryChange.objects.filter(product=product, reason='出售').order_by('change_time')

    if not sales_data.exists():
        return None  # 没有销售记录

    # 提取销售时间和销售量数据
    change_times = np.array([sale.change_time for sale in sales_data])
    change_amounts = np.array([abs(sale.change_amount) for sale in sales_data])

    if change_times.size == 0 or change_amounts.size == 0:
        return None  # 销售时间或销售量数据缺失

    # 计算从第一次销售到各次销售的天数
    first_sale_time = change_times[0]
    days_since_first_sale = (change_times - first_sale_time).astype('timedelta64[D]').astype(int)

    # 去除异常值（例如销售量超过95百分位的部分）
    threshold = np.percentile(change_amounts, 95)
    filtered_indices = change_amounts < threshold
    X = days_since_first_sale[filtered_indices].reshape(-1, 1)
    y = change_amounts[filtered_indices]

    # 如果数据量不足，无法进行预测
    if len(X) < 2:
        return None

    # 创建并训练多项式回归模型
    poly_model = make_pipeline(PolynomialFeatures(degree=2), LinearRegression())
    poly_model.fit(X, y)

    # 当前天数和库存量
    current_days = (change_times[-1] - first_sale_time).days
    current_stock = product.quantity

    # 使用多项式回归模型预测未来 days_ahead 天的销售量
    future_days = np.arange(current_days + 1, current_days + days_ahead + 1).reshape(-1, 1)
    future_sales_pred = poly_model.predict(future_days)

    # 获取历史销售数据的标准差
    sales_std = np.std(change_amounts)
    adjusted_std = sales_std * 0.5

    # 蒙特卡罗模拟
    future_sales_sim = np.random.normal(future_sales_pred, adjusted_std, (num_simulations, days_ahead))
    future_sales_sim = np.clip(future_sales_sim, 0, None)

    # 计算每次模拟的剩余库存
    total_sales_sim = future_sales_sim.sum(axis=1)
    remaining_stock_sim = current_stock - total_sales_sim

    # 分析模拟结果，计算补货需求
    predicted_stock = np.percentile(remaining_stock_sim, 5)
    restock_amount = max(0, -predicted_stock)

    return int(restock_amount / 12)


import numpy as np
import pandas as pd
import re  # 导入正则表达式模块
from django.db.models import Sum
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from .models import InventoryChange, Product
from django.contrib.auth.models import User
from django.http import JsonResponse
def user_clustering(n_clusters=4):
    try:
        # 获取所有有行为记录的用户，排除默认用户（假设用户名为 '默认用户'）
        users_with_orders = InventoryChange.objects.values('user').distinct().exclude(user='默认用户')

        # 检查是否有足够的用户进行聚类
        if len(users_with_orders) < n_clusters:
            return JsonResponse({'status': 'error', 'message': f"用户数量 {len(users_with_orders)} 小于指定的聚类数量 {n_clusters}。请减少聚类数量或增加用户。"}, status=400)

        # 初始化存储用户特征的列表
        user_data = []

        for user_record in users_with_orders:
            user_id = user_record['user']

            # 过滤符合用户名格式的用户
            if not re.match(r'用户\d+', user_id):
                continue  # 如果用户不符合格式，则跳过

            # 用户的购买订单
            orders = InventoryChange.objects.filter(user=user_id)

            # 计算特征
            total_purchases = orders.count()  # 购买次数
            total_spent = sum(order.change_amount * order.product.price for order in orders)  # 总消费金额
            avg_purchase_value = total_spent / total_purchases if total_purchases > 0 else 0  # 平均每次消费
            user_instance = User.objects.filter(username=user_id).first()  # 尝试获取用户实例

            if user_instance:
                active_days = (user_instance.last_login - user_instance.date_joined).days if user_instance.last_login else 0  # 活跃天数
            else:
                # 如果用户不存在，则记录特征为0
                active_days = 0

            categories_viewed = Product.objects.filter(inventorychange__in=orders).values('category').distinct().count()  # 浏览商品种类数

            # 将用户特征加入列表
            user_data.append([active_days, total_purchases, total_spent, avg_purchase_value, categories_viewed])

        # 打印用户特征数据长度以进行调试
        print(f"用户特征数据长度: {len(user_data)}")
        if len(user_data) < n_clusters:
            return JsonResponse({'status': 'error', 'message': f"有效用户数量 {len(user_data)} 小于指定的聚类数量 {n_clusters}。请增加用户行为数据。"}, status=400)

        # 转换为 NumPy 数组
        user_data = np.array(user_data)

        # 标准化用户特征
        scaler = StandardScaler()
        user_data = scaler.fit_transform(user_data)

        # 使用 KMeans 进行聚类
        kmeans = KMeans(n_clusters=n_clusters, random_state=42)
        clusters = kmeans.fit_predict(user_data)

        # 为每个用户分配群体标签
        user_clusters = pd.DataFrame({'user_id': [user_record['user'] for user_record in users_with_orders if re.match(r'用户\d+', user_record['user'])], 'cluster': clusters})

        # 假设 User 模型中有 cluster 字段，保存用户群体信息
        for index, user_record in enumerate(user_clusters.to_dict('records')):
            user = User.objects.filter(username=user_record['user_id']).first()  # 使用 filter() 来避免 DoesNotExist 异常
            if user:
                user.cluster = user_record['cluster']  # 确保 User 模型中有 cluster 字段
                user.save()

        return JsonResponse({'status': 'success', 'message': '用户分析已成功运行。'}, status=200)

    except Exception as e:
        return JsonResponse({'status': 'error', 'message': f"用户分析过程中发生错误: {str(e)}"}, status=500)

