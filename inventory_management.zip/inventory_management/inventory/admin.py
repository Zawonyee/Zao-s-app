from django.contrib import admin
from django.db.models import Sum
from .utils import sales_analysis, restock_prediction
from django.db import models
from django.urls import path, reverse
from django.utils.html import format_html
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
import seaborn as sns
from io import BytesIO
import base64
from datetime import datetime, timedelta
from django.template.response import TemplateResponse
from django.utils import timezone
from .models import Product, InventoryChange
import matplotlib as mpl

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimSun']  # 使用宋体
plt.rcParams['axes.unicode_minus'] = False     # 解决负号显示问题

# 设置 seaborn 样式
sns.set_style("whitegrid")     # 设置白色网格样式
sns.set_palette("husl")        # 设置颜色主题
sns.set_context("notebook")    # 设置绘图上下文

# 自定义字体大小
plt.rcParams['font.size'] = 12         # 默认字体大小
plt.rcParams['axes.titlesize'] = 14    # 标题字体大小
plt.rcParams['axes.labelsize'] = 12    # 轴标签字体大小

# 如果上述字体设置不生效，可以尝试以下备选方案：
try:
    plt.rcParams['font.sans-serif'] = ['SimSun']
except:
    plt.rcParams['font.sans-serif'] = ['SimHei']  # 使用黑体作为备选
    
# 确保图表背景为白色
plt.rcParams['figure.facecolor'] = 'white'
plt.rcParams['axes.facecolor'] = 'white'

# 自定义颜色方案
color_palette = ['#2ecc71', '#3498db', '#e74c3c', '#f1c40f', '#9b59b6']

# 自定义 Product 的 ModelAdmin
class ProductAdmin(admin.ModelAdmin):
    list_display = ('name', 'price', 'quantity', 'category', 'total_sales', 'predicted_restock')

    def total_sales(self, obj):
        total_sales = InventoryChange.objects.filter(product=obj, reason='出售').aggregate(total_sales=models.Sum('change_amount'))
        return abs(total_sales['total_sales']) if total_sales['total_sales'] else 0

    total_sales.short_description = '总销量'

    def predicted_restock(self, obj):
        """计算并返回补货需求预测"""
        prediction = restock_prediction(obj.id)  # 调用补货预测函数
        return prediction if prediction is not None else "数据不足"

    predicted_restock.short_description = '预测补货需求'

    def sales_ratio_analysis_view(self, request):
        """
        计算并显示所有产品的销售占比情况。
        """
        # 获取所有产品的销售记录
        sales_data = InventoryChange.objects.filter(reason='出售')

        # 将销售记录转换为DataFrame
        sales_df = pd.DataFrame(list(sales_data.values('product__name', 'change_amount')))
        sales_df['change_amount'] = sales_df['change_amount'].abs()  # 确保销售量是非负的

        # 计算各个产品的总销售量
        total_sales = sales_df.groupby('product__name')['change_amount'].sum().reset_index()
        total_sales.columns = ['product_name', 'total_sales']

        # 计算占比
        total_sales_sum = total_sales['total_sales'].sum()
        total_sales['percentage'] = total_sales['total_sales'] / total_sales_sum * 100 if total_sales_sum > 0 else 0

        # 创建饼图
        fig, ax = plt.subplots()
        ax.pie(total_sales['percentage'], labels=total_sales['product_name'], autopct='%1.1f%%', startangle=90)
        ax.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.

        # 保存图像到内存缓冲区并转换为Base64编码
        buffer = BytesIO()
        plt.savefig(buffer, format='png', dpi=300)
        buffer.seek(0)
        image_base64 = base64.b64encode(buffer.read()).decode('utf-8')
        buffer.close()
        plt.clf()  # 清除当前图形

        # 传递给模板的数据
        context = {
            'sales_image': image_base64,
        }

        return TemplateResponse(request, "admin/sales_ratio_analysis.html", context)

    def change_view(self, request, object_id, form_url='', extra_context=None):
        """
        修改页面视图，增加补货预测按钮���结果。
        """
        extra_context = extra_context or {}
        product_id = object_id

        # 获取补货预测值
        restock_demand = restock_prediction(product_id)
        if restock_demand is not None:
            restock_message = f"预测的补货需求: {restock_demand:.2f} 件"
        else:
            restock_message = "数据不足，无法进行预测"

        # 添加销售分析
        sales_analysis_url = reverse('admin:custom_sales_analysis', args=[product_id])
        extra_context['sales_analysis_button'] = format_html(
            '<a class="button" href="{}" style="margin-top: 10px;">销售分析</a>', sales_analysis_url
        )



        extra_context['restock_message'] = restock_message

        # 添加销售占比分析按钮
        sales_ratio_analysis_url = reverse('admin:sales_ratio_analysis')
        extra_context['sales_ratio_analysis_button'] = format_html(
            '<a class="button" href="{}" style="margin-top: 10px;">分析所有产品销售占比</a>', sales_ratio_analysis_url
        )

        return super().change_view(request, object_id, form_url, extra_context=extra_context)

    def sales_analysis_view(self, request, product_id):
        """
        自定义视图函数用于显示特定商品的销售分析页面，���生成��间分布图。
        """
        product = Product.objects.get(id=product_id)
        total_sales = sales_analysis(product)  # 确保调用方式一致

        # 获取该产品的销售记录，并按销售时间进行排序
        sales_data = InventoryChange.objects.filter(product=product, reason='出售').order_by('change_time')

        # 将查询集转换为DataFrame便于处理日期
        sales_df = pd.DataFrame(list(sales_data.values('change_time', 'change_amount')))

        # 将所有日期对象转换为无时区信息的形式
        sales_df['change_time'] = pd.to_datetime(sales_df['change_time']).dt.tz_localize(None)

        # 计算每个月份的总销售量，并取绝对值
        monthly_sales = sales_df.groupby(pd.Grouper(key='change_time', freq='M'))['change_amount'].sum().abs()

        # 获取近一个月的数据
        recent_month_sales = sales_df[
            sales_df['change_time'] >= (datetime.now().replace(tzinfo=None) - timedelta(days=30))]
        recent_month_sales_sum = abs(recent_month_sales['change_amount'].sum())

        # 获取近一年的数据
        recent_year_sales = sales_df[
            sales_df['change_time'] >= (datetime.now().replace(tzinfo=None) - timedelta(days=365))]
        recent_year_sales_sum = abs(recent_year_sales['change_amount'].sum())

        # 计算所有销售货品的总销售量
        all_sales_sum = abs(monthly_sales.sum())

        # 计算近一个月销售量占所有销售货品的比例
        recent_month_percentage = recent_month_sales_sum / all_sales_sum if all_sales_sum > 0 else 0

        # 计算近一年销售量占所有销售货品的比例
        recent_year_percentage = recent_year_sales_sum / all_sales_sum if all_sales_sum > 0 else 0

        # 计算其余时间销售量占所有销售货品的比例
        remaining_time_percentage = 1 - recent_month_percentage - recent_year_percentage

        # 创建新的图形
        fig = plt.figure(figsize=(24, 8))

        # 使用 gridspec 创建一个 1 行 2 列的网格布局
        gs = fig.add_gridspec(nrows=1, ncols=2, wspace=0.4)  # 增加水平间距

        # 绘制按月份的销售量条形图
        ax_bar = fig.add_subplot(gs[0, 0])
        bar_plot = ax_bar.bar(monthly_sales.index, monthly_sales, color='teal', edgecolor='skyblue', linewidth=15,
                              alpha=0.7)
        ax_bar.set_title(f'{product.name} 每月销售量分布', fontsize=16)
        ax_bar.set_xlabel('月份', fontsize=14)
        ax_bar.set_ylabel('销售量', fontsize=14)
        ax_bar.grid(True, which='both', axis='y', linestyle='--', linewidth=0.5)
        ax_bar.tick_params(axis='x', labelrotation=15)

        # 添加销售量数据到每个柱子上
        for index, value in enumerate(monthly_sales):
            ax_bar.text(index, value + 0.1, f"{value}", ha='center', va='bottom', fontsize=10)

        # 绘制环形图
        labels = ['近一个月', '近一年', '其余时间']
        sizes = [recent_month_percentage, recent_year_percentage, remaining_time_percentage]
        sizes = [max(size, 0) for size in sizes]  # 确保所有数据是非负数
        sizes = [size / sum(sizes) for size in sizes]  # 重新归一化
        ax_pie_time = fig.add_subplot(gs[0, 1])
        ax_pie_time.pie(sizes, labels=labels, autopct='%1.1f%%', startangle=90,
                        colors=['skyblue', 'lightgreen', 'lightcoral'])
        ax_pie_time.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.
        ax_pie_time.set_title(f'销售量时间占比', fontsize=16)

        # 获取所有产品的近一个月销售数据
        all_sales_data = InventoryChange.objects.filter(reason='出售',
                                                        change_time__gte=datetime.now() - timedelta(days=30))
        all_sales_df = pd.DataFrame(list(all_sales_data.values('product__name', 'change_amount')))
        all_sales_df['change_amount'] = all_sales_df['change_amount'].abs()

        # 计算所有���品的近一个月销售量总和
        all_products_recent_month_sales_sum = all_sales_df.groupby('product__name')['change_amount'].sum().sum()

        # 计算特定产品近一个月的销售量
        specific_product_recent_month_sales_sum = all_sales_df[all_sales_df['product__name'] == product.name][
            'change_amount'].sum()

        # 确保特定产品的销售量是非负数
        specific_product_recent_month_sales_sum = max(specific_product_recent_month_sales_sum, 0)

        # 计算特定产品在所有产品中的销售量占比
        specific_product_recent_month_percentage = specific_product_recent_month_sales_sum / all_products_recent_month_sales_sum if all_products_recent_month_sales_sum > 0 else 0

        # 绘制特定产品在所有产品近一个月销售量中的占比
        labels_specific_product = [product.name, '其他产品']
        sizes_specific_product = [specific_product_recent_month_percentage,
                                  1 - specific_product_recent_month_percentage]
        sizes_specific_product = [max(size, 0) for size in sizes_specific_product]  # 确保所有数据是非负数
        sizes_specific_product = [size / sum(sizes_specific_product) for size in sizes_specific_product]  # 重新归一化

        # 确保饼图数据之和为1
        assert sum(sizes_specific_product) == 1.0, "Pie chart data does not sum up to 1"

        # 获取所有产品的销售记录
        all_total_sales_data = InventoryChange.objects.filter(reason='出售')
        all_total_sales_df = pd.DataFrame(list(all_total_sales_data.values('product__name', 'change_amount')))
        all_total_sales_df['change_amount'] = all_total_sales_df['change_amount'].abs()

        # 计算各个产品的总销售量
        all_total_sales = all_total_sales_df.groupby('product__name')['change_amount'].sum().reset_index()
        all_total_sales.columns = ['product_name', 'total_sales']

        # 计算总销售量
        all_total_sales_sum = all_total_sales['total_sales'].sum()

        # 计算占比
        all_total_sales['percentage'] = all_total_sales[
                                            'total_sales'] / all_total_sales_sum * 100 if all_total_sales_sum > 0 else 0

        # 创建一个新的图形来绘制所有产品的销售量占比
        fig2 = plt.figure(figsize=(12, 8))
        ax_pie_all = fig2.add_subplot(111)
        ax_pie_all.pie(all_total_sales['percentage'], labels=all_total_sales['product_name'],
                       autopct='%1.1f%%', startangle=90)
        ax_pie_all.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.
        ax_pie_all.set_title('所有产品销售总量占比', fontsize=16)

        # 保存图像到内存缓冲区并转换为Base64编码
        buffer1 = BytesIO()
        plt.figure(fig.number)
        plt.savefig(buffer1, format='png', dpi=300)
        buffer1.seek(0)
        image_base64_1 = base64.b64encode(buffer1.read()).decode('utf-8')
        buffer1.close()

        # 清除绘图环境中的当前Axes，避免图表重叠
        plt.figure(fig.number).clf()

        # 保存第二个图像到内存缓冲区并转换为Base64编码
        buffer2 = BytesIO()
        plt.figure(fig2.number)
        plt.savefig(buffer2, format='png', dpi=300)
        buffer2.seek(0)
        image_base64_2 = base64.b64encode(buffer2.read()).decode('utf-8')
        buffer2.close()

        # 清除绘图环境中的当前Axes，避免图表重叠
        plt.figure(fig2.number).clf()

        # 获取所有产品的数据用于聚类分析
        product_data = Product.objects.all().values('name', 'price', 'quantity')
        product_df = pd.DataFrame(list(product_data))

        # 获取每个产品的销售数据
        sales_data = InventoryChange.objects.filter(reason='出售').values('product__name', 'change_time',
                                                                          'change_amount')
        sales_df = pd.DataFrame(list(sales_data))
        sales_df['change_time'] = pd.to_datetime(sales_df['change_time']).dt.tz_localize(None)

        # 计算每个产品的销售频率（销售次数/天）
        sales_frequency_df = sales_df.groupby('product__name')['change_time'].apply(
            lambda x: len(x) / ((x.max() - x.min()).days + 1) if (x.max() - x.min()).days > 0 else len(x)
        ).reset_index(name='sales_frequency')

        # 计算每个产品的平均销售间隔（天）
        def calculate_average_interval(times):
            if len(times) < 2:
                return 0
            times_sorted = sorted(times)
            intervals = [(times_sorted[i + 1] - times_sorted[i]).days for i in range(len(times_sorted) - 1)]
            return sum(intervals) / len(intervals) if intervals else 0

        sales_interval_df = sales_df.groupby('product__name')['change_time'].apply(
            calculate_average_interval
        ).reset_index(name='average_sales_interval')

        # 获取每个产品的总销售量
        total_sales_data = InventoryChange.objects.filter(reason='出售').values('product__name').annotate(total_sales=Sum('change_amount'))
        total_sales_df = pd.DataFrame(list(total_sales_data))
        total_sales_df.rename(columns={'product__name': 'name'}, inplace=True)

        # 合并产品数据、销售频率和销售间隔数据
        product_sales_df = pd.merge(product_df, total_sales_df, left_on='name', right_on='name', how='left')
        product_sales_df = pd.merge(product_sales_df, sales_frequency_df, left_on='name', right_on='product__name',
                                    how='left')
        product_sales_df = pd.merge(product_sales_df, sales_interval_df, left_on='name', right_on='product__name',
                                    how='left')
        product_sales_df.fillna(0, inplace=True)

        # 提取需要用于聚类的特征列：价格、库存量、总销售量、销售频率、平均销售间隔
        features = product_sales_df[['price', 'quantity', 'total_sales', 'sales_frequency', 'average_sales_interval']]

        # 数据标准化处理
        scaler = StandardScaler()
        features_scaled = scaler.fit_transform(features)

        # 使用K-means聚类，假设聚为3类
        kmeans = KMeans(n_clusters=3, random_state=42)
        product_sales_df['cluster'] = kmeans.fit_predict(features_scaled)

        # 绘制聚类结果的散点图（使用价格与销售频率）
        fig3 = plt.figure(figsize=(10, 6))
        ax_cluster = fig3.add_subplot(111)

        # 不同簇的颜色定义
        colors = ['red', 'blue', 'green']
        for cluster_num in range(3):
            cluster_data = product_sales_df[product_sales_df['cluster'] == cluster_num]
            ax_cluster.scatter(cluster_data['price'], cluster_data['sales_frequency'],
                               s=cluster_data['quantity'], alpha=0.6, color=colors[cluster_num],
                               label=f'Cluster {cluster_num + 1}')

        ax_cluster.set_title('产品聚类分析（价格与销售频率）', fontsize=16)
        ax_cluster.set_xlabel('价格', fontsize=14)
        ax_cluster.set_ylabel('销售频率（次/天）', fontsize=14)
        ax_cluster.legend()
        ax_cluster.grid(True, linestyle='--', linewidth=0.5)

        # 保存第��个图像到内存缓冲区并转换为Base64编码
        buffer3 = BytesIO()
        plt.figure(fig3.number)
        plt.savefig(buffer3, format='png', dpi=300)
        buffer3.seek(0)
        image_base64_3 = base64.b64encode(buffer3.read()).decode('utf-8')
        buffer3.close()

        # 清除绘图环境中的当前Axes，避免图表重叠
        plt.figure(fig3.number).clf()
        # 对产品的销售总量取绝对值，确保所有数据都是正数
        product_sales_df['total_sales'] = product_sales_df['total_sales'].abs()

        # 绘制第四张图，将每个产品归到每一个类并详细标注
        fig4 = plt.figure(figsize=(12, 8))
        ax_product_cluster = fig4.add_subplot(111)

        # 用不同的颜色表示不同的簇
        colors = ['red', 'blue', 'green']
        labels = ['高附加值产品产品', '高价低频高利润型产品', '低价高频高依赖型产品']  # 自定义每个簇的描述
        for cluster_num in range(3):
            cluster_data = product_sales_df[product_sales_df['cluster'] == cluster_num]
            ax_product_cluster.scatter(
                cluster_data['price'],
                cluster_data['total_sales'],
                s=cluster_data['quantity'],
                alpha=0.6,
                color=colors[cluster_num],
                label=labels[cluster_num]  # 使用自定义标签
            )
            # 标注每个点的产品名称
            for _, row in cluster_data.iterrows():
                ax_product_cluster.text(
                    row['price'],
                    row['total_sales'],
                    row['name'],
                    fontsize=8,
                    ha='right',
                    color=colors[cluster_num]
                )

        ax_product_cluster.set_title('各类产品聚类分布图（价格与总销售量）', fontsize=16)
        ax_product_cluster.set_xlabel('价格', fontsize=14)
        ax_product_cluster.set_ylabel('总销售量', fontsize=14)
        ax_product_cluster.legend()
        ax_product_cluster.grid(True, linestyle='--', linewidth=0.5)

        # 保存第四个图像到内存缓冲区并转换为Base64编码
        buffer4 = BytesIO()
        plt.figure(fig4.number)
        plt.savefig(buffer4, format='png', dpi=300)
        buffer4.seek(0)
        image_base64_4 = base64.b64encode(buffer4.read()).decode('utf-8')
        buffer4.close()

        # 清除绘图环境中的当前Axes，避免图表重叠
        plt.figure(fig4.number).clf()
        # 传递给模板的数据
        context = {
            'product': product,
            'sales_image_1': image_base64_1,
            'sales_image_2': image_base64_2,
            'cluster_image': image_base64_3,
            'sales_image_4': image_base64_4,
            'total_sales': total_sales,
        }

        return TemplateResponse(request, "admin/sales_analysis.html", context)


    def get_urls(self):
        """
        获取自定义 URL 路径。
        """
        urls = super().get_urls()
        custom_urls = [
            path('sales-ratio-analysis/', self.admin_site.admin_view(self.sales_ratio_analysis_view),name='sales_ratio_analysis'),
            path('<int:product_id>/custom-sales-analysis/', self.admin_site.admin_view(self.sales_analysis_view),name='custom_sales_analysis'),
        ]
        return custom_urls + urls

admin.site.register(Product, ProductAdmin)
admin.site.register(InventoryChange)
