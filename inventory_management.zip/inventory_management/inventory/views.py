from django.shortcuts import render, redirect, get_object_or_404
from .models import Product, InventoryChange
from .forms import ProductForm
import pandas as pd
from .forms import ImportForm
from django.contrib import messages
import os
# 显示所有货品
def product_list(request):
    products = Product.objects.all()
    return render(request, 'inventory/product_list.html', {'products': products})

# 添加货品
def product_create(request):
    if request.method == 'POST':
        form = ProductForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('product_list')
    else:
        form = ProductForm()
    return render(request, 'inventory/product_form.html', {'form': form})


# 编辑货品
def product_update(request, pk):
    product = get_object_or_404(Product, pk=pk)
    old_quantity = product.quantity  # 记录更新前的库存
    if request.method == 'POST':
        form = ProductForm(request.POST, instance=product)
        if form.is_valid():

            form.save()  # 保存更新

            # 计算库存变化
            change_amount = product.quantity - old_quantity

            # 如果库存变化不为零，则记录变化
            if change_amount != 0:
                InventoryChange.objects.create(
                    product=product,
                    change_amount=change_amount,
                    reason = '出售' if change_amount < 0 else '补货',
                )

            messages.success(request, "货品更新成功!")
            return redirect('product_list')  # 重定向到货品列表页面
    else:
        form = ProductForm(instance=product)

    return render(request, 'inventory/product_form.html', {'form': form})


# 展示库存变化
def inventory_change_list(request):
    changes = InventoryChange.objects.all().order_by('-change_time')  # 按时间降序排列
    return render(request, 'inventory/inventory_change_list.html', {'changes': changes})

# 删除货品
def product_delete(request, pk):
    product = get_object_or_404(Product, pk=pk)
    if request.method == 'POST':
        product.delete()
        return redirect('product_list')
    return render(request, 'inventory/product_confirm_delete.html', {'product': product})




# 处理 Excel 文件并将数据导入到数据库的函数
def handle_uploaded_file(f):
    df = pd.read_excel(f)

    # 遍历 DataFrame 并创建 Product 对象
    for _, row in df.iterrows():
        Product.objects.create(
            name=row['名称'],
            price=row['价格'],
            quantity=row['库存数量'],
            category=row['类别'],
            production_date = row['生产日期'],
            shelf_life = row['保质期']
        )


# 导入货品的视图函数
def import_products(request):
    if request.method == "POST":
        form = ImportForm(request.POST, request.FILES)
        if form.is_valid():
            # 处理上传的文件
            handle_uploaded_file(request.FILES['file'])
            messages.success(request, "货品导入成功!")
            return redirect('product_list')  # 重定向到货品列表页面
    else:
        form = ImportForm()

    return render(request, 'import_form.html', {'form': form})


# 清空货品的视图函数
def clear_products(request):
    if request.method == "POST":
        Product.objects.all().delete()  # 删除所有货品记录
        messages.success(request, "所有货品已清空!")
        return redirect('product_list')  # 清空后重定向到货品列表页面

    return render(request, 'inventory/clear_products.html')

from django.core.files.storage import FileSystemStorage


def handle_uploaded_excel(file):
    # 使用 pandas 解析 Excel 文件
    df = pd.read_excel(file, engine='openpyxl')

    # 确保日期列正确转换为 datetime 类型
    if '变化时间' in df.columns:
        df['变化时间'] = pd.to_datetime(df['变化时间'], errors='coerce')  # 尝试转换日期，并忽略无效日期

    # 遍历每一行并将数据保存到数据库
    for _, row in df.iterrows():
        user = row['用户']

        # 根据 '商品名称' 查找或创建 Product 实例
        try:
            product = Product.objects.get(name=row['商品名称'])
        except Product.DoesNotExist:
            product = Product.objects.create(name=row['商品名称'])
        except Product.MultipleObjectsReturned:
            product = Product.objects.filter(name=row['商品名称']).first()
            # 可以在这里添加日志或异常处理，说明为什么存在多个对象

        change_amount = row['变化数量']

        # 设置原因
        reason = '出售' if change_amount < 0 else '补货'

        # 创建 InventoryChange 实例并保存
        if change_amount != 0:
            InventoryChange.objects.create(
                user=user,
                product=product,
                change_amount=change_amount,
                reason=reason,
                change_time=row['变化时间']
            )


def import_excel(request):
    if request.method == "POST":
        form = ImportForm(request.POST, request.FILES)
        if form.is_valid():
            # 获取上传的文件
            excel_file = request.FILES['file']

            # 保存上传的文件到本地（临时）
            fs = FileSystemStorage()
            filename = fs.save(excel_file.name, excel_file)

            try:
                # 处理 Excel 文件
                handle_uploaded_excel(fs.path(filename))
                messages.success(request, 'Excel 数据导入成功！')
            except ValueError as ve:
                messages.error(request, f'日期转换错误: {ve}')
            except Exception as e:
                messages.error(request, f'导入失败: {e}')
            finally:
                # 清理临时文件
                if os.path.exists(fs.path(filename)):
                    os.remove(fs.path(filename))

            return redirect('inventory_change_list')  # 重定向到库存列表页面
    else:
        form = ImportForm()

    return render(request, 'inventory/import_excel.html', {'form': form})

from django.utils import timezone
from django.db.models import Max
import datetime
def detect_anomalies_all_view(request):
    # 获取所有产品
    products = Product.objects.all()
    anomalies = []

    for product in products:
        issues = []  # 存储当前产品的所有异常情况

        # 获取该产品的最后销售记录
        last_sale_time = InventoryChange.objects.filter(product=product).aggregate(Max('change_time'))['change_time__max']

        # 将生产日期转换为 datetime.datetime
        production_date_time = timezone.make_aware(
            datetime.datetime.combine(product.production_date, datetime.datetime.min.time()))

        # 检查是否超出保质期
        shelf_expiration_date = production_date_time + timezone.timedelta(days=product.shelf_life)
        if timezone.now() > shelf_expiration_date:
            issues.append('该货品超出保质期')

        # 检查该产品的最后销售时间
        if last_sale_time is None:
            # 产品从未售出
            issues.append('该货品长时间没有销售记录')
        else:
            # 检查是否长时间没有销售记录
            if (timezone.now() - last_sale_time).days > 14:  # 修改为14天
                issues.append('该货品长时间没有销售记录')

        # 如果当前产品有异常情况，则添加到异常列表
        if issues:
            anomalies.append({
                'product': product,
                'issues': issues,  # 使用issues列表来存储所有异常情况
            })

    return render(request, 'inventory/anomalies.html', {'anomalies': anomalies})
from .utils import restock_prediction


def manage_suggestions_view(request):
    # 查询滞销商品（例如，90天内没有销售的商品）
    unsold_products = Product.objects.filter(
        inventorychange__isnull=True
    ).distinct()

    # 获取库存状态及补货建议
    low_stock_products = []
    high_stock_products = []
    restock_suggestions = []

    for product in Product.objects.all():
        predicted_restock = restock_prediction(product.id)

        # 计算当前库存与预测的补货量的关系
        current_stock = product.quantity

        if predicted_restock is not None:
            if predicted_restock > 0:
                restock_suggestions.append({
                    'product': product.name,
                    'suggestion': f'建议补货数量：{predicted_restock} 件。'
                })

            # 根据预测结果动态判断库存状态
            if current_stock < predicted_restock:
                low_stock_products.append(product)
            elif current_stock > predicted_restock * 1.5:  # 例如，认为库存大于预测补货量的1.5倍是过高
                high_stock_products.append(product)

    return render(request, 'inventory/manage_suggestions.html', {
        'unsold_products': unsold_products,
        'low_stock_products': low_stock_products,
        'high_stock_products': high_stock_products,
        'restock_suggestions': restock_suggestions,
    })
